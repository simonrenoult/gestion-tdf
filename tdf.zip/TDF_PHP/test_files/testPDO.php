<?php
	include '../php_files/php_class/bdd.class.php';
	
	
	
	
		$bdd = new BDD();
		$req = "SELECT * FROM TDF_PAYS";
		
		echo $req;
		try {
			$query = $bdd->getBDD()->prepare($req);
			$query->execute();
			
			
			echo"<table width=\"100%\" border=\"1\" cellspacing=\"1\" cellpadding=\"1\" >";
		
			
			
			while ($donnee = $query->fetch(PDO::FETCH_NUM)){
				echo "<tr>";
				for($i=0;$i<count($donnee);$i++){
					echo "<td>".$donnee[$i]."</td>";
				}	
				echo"</tr>";
				
				
				
			}
			
			
			echo"</table>";	
			$query->closeCursor();
			
			
		}catch (Exception $e){}
		

	
?>