<?php

	//connexion � la base de donn�e avec le module OCSI8.
	$bdd = oci_connect("admin", "admin","xe");
	if (!$bdd){
		$e = oci_error();
		print htmlentities($e['message']);
		exit;
	}
	else {
		echo "Connexion �tablie";
	}

	//lecture dans la base.
	
	$req = 'SELECT * FROM TDF_COUREUR WHERE ROWNUM <= 5';
	$cur = oci_parse($bdd, $req);
	$res = oci_execute($cur,OCI_DEFAULT);
	
	echo "<br />$res<br />";
	
	while ($row = oci_fetch_array($cur,OCI_NUM)){
		print_r($row);
	}
	
	oci_close($bdd);
?>