<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<!--
	Include obligatoire afin de permettre l'initialisation des variables javascript avec la fonction " autoCompletion_init(...) "
-->
<?php include ("./autoCompletion_module/autoCompletion_config.php"); ?>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
		<title>Table coureur</title>
		
		<!--
			HEADER obligatoire pour le module d'autoCompletion
		-->
		<link rel="stylesheet" type="text/css" href="./autoCompletion_module/css/autoCompletion_style.css">
		<script type="text/javascript" src="./autoCompletion_module/js/autoCompletion_lib.js"></script>
		<script type="text/javascript">
			autoCompletion_init('<?php echo $border_no_foc ?>','<?php echo $border_foc ?>','<?php echo $background_color_no_foc ?>','<?php echo $background_color_foc ?>','<?php echo $file_ref ?>');
		</script>
		<!--
			FIN HEADER du module de l'autoCompletion
		-->
	<link rel="stylesheet" media="screen" type="text/css" title="Design" href="../css_files/coureur.css"  /> 	
	</head>
	<body>
	
		<div id="header">
			
			<h1>Base d'administration des tables du TDF 2011</h1>
			<h3><i>Table coureur (ecrit en dur)</i></h3>
				
		</div>
		
		<div id="left_size">
			<fieldset>
			<legend>Rechercher un coureur :</legend>
			
			<div id="recherche">
					
					
					<center>
					<!--
						DEBUT de la partie obligatoire a definir dans la partie BODY
								Ne modifiez surtout pas cette partie sinon cela ne fonctionnera plus...
					-->
					<form action="#" name="autoCompletion" onSubmit="return false;">
						<div id="autoCompletion_input">
							<input id="list0" type=text size=50 name="autoCompletion_input"  onMouseOver="give_focus_style(0,1);" onBlur="focus_off();" onFocus="focus_on();" onKeyUp="event_capture(this.value,event);">
						</div>
						<div id="autoCompletion_answer" onClick="focus_on();"></div>
					</form>
					<!--
						FIN de la partie BODY du module d'autoCompletion
					-->
					</center>
					<center>
					<?php
					include_once '../php_files/php_class/bdd.class.php';
					if (!empty($_GET)){
					
						//if ( !empty($_GET['id']) ) echo " Coureur : ( id = ".$_GET['id']." )";
						//if ( !empty($_GET['search']) ) echo " Recherche : '".$_GET['search']."' ";
						
						
						
						$req = "select * from tdf_coureur where n_coureur =".$_GET['id'];
						$bdd = new BDD();
						$query = $bdd->getBDD()->query($req);
						$IDcoureur = array();
						while ($donnee = $query->fetch(PDO::FETCH_ASSOC)){
							$IDcoureur = $donnee; 
						}
						$query->closeCursor();
					
						
					}
						
					?>
					</center>
				
			</div>	
		</fieldset>
		</div>	
		
		<div id="identiteCoureur">
			<?php
			
			include '../php_files/AjouterCoureur.php';
			//print_r($IDcoureur);
			//var_dump($IDcoureur['ANNEE_NAISSANCE']);
			 ?>
		</div>	
				
	</body>
</html>
