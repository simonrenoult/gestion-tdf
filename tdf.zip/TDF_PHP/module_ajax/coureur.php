<?php


try {
	copy("./autoCompletion_module/config_files/coureurConfig.php", "./autoCompletion_module/autoCompletion_config.php");
	
	include '../php_files/TraitementFormulaireCoureur.php';
	
	include 'autoCompletion.php';
	
	include '../php_files/FormulaireCoureur.php';
	
}catch (Exception $e){
	
}



?>