<?php


try {
	copy("./autoCompletion_module/config_files/paysConfig.php", "./autoCompletion_module/autoCompletion_config.php");
	
	include '../php_files/TraitementFormulairePays.php';
	
	include 'autoCompletion.php';
	
	include '../php_files/FormulairePays.php';
	
}catch (Exception $e){
	
}



?>