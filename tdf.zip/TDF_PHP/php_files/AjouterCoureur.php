
	
	<fieldset>
	<legend> Gestion d'un coureur </legend>	
	
		<form action="../php_files/TraitementAjoutercoureur.php" method="post" >
		
		   <?php 
		        include'comboboxCoureur.php';
		       // include '/php_class/bdd.class.php';
		        $bdd = new BDD();
		    ?>
		   <p><label for="nom">Nom* : </label><input type="text" name="nom" value ="<?php if (isset($IDcoureur)){echo $IDcoureur['NOM'];}else{echo "";} ?>"/></p>
	       <p><label for="prenom">Prenom* : </label><input type="text" name="prenom" value ="<?php if (isset($IDcoureur)){echo $IDcoureur['PRENOM'];}else{echo "";} ?>"/></p>  
	       <p><label for="date_naissance">Date de Naissance : </label>
	       	<select name="date_naissance" id="date_naissance">
	       	<?php if(isset($IDcoureur)){remplirComboboxDate(50,$IDcoureur['ANNEE_NAISSANCE']);}else{remplirComboboxDate(50,0);} ?>
	       	</select>
	        </p>  
	        
	       <p><label for="pays_origine">Pays d'origine* : </label> 
	       <select name="pays_origine" id="pays_origine"> 
		   <?php 
		   if(isset($IDcoureur)){
		   		remplirComboboxSQL($bdd->getBDD(),'Select * from tdf_pays order by nom asc', 'NOM', 'CODE_TDF',$IDcoureur['CODE_TDF']);
		   }else{
		   		remplirComboboxSQL($bdd->getBDD(),'Select * from tdf_pays order by nom asc', 'NOM', 'CODE_TDF',"");
		   }	
		   	?>   
		   </select>
		   </p>  
	        
	       	    
		     <p><label for="annee_tdf">Annee de votre premier tour de france : </label>
	         <select name="annee_tdf" id="annee_tdf">
	       	 <?php if(isset($IDcoureur)){remplirComboboxDate(50,$IDcoureur['ANNEE_TDF']);}else{remplirComboboxDate(50,0);} ?>
	         </select>
	         </p>  
	       
	         
			<br><br>
			
				<input type="submit" name="valider" value="Ajouter"  />
				<input type="submit" name="maj" value="Mettre � jour"/>
				<input type="submit" name="supprimer" value="Supprimer" />
				<input type="reset" value="R�initialiser"  />
				
				
		
	    </form>
	
	</fieldset>
	<p>*Champ obligatoirement rempli</p>
	
	
	
	
	
	
	
	<!-- onSubmit = "return maFonctionJs();" , on clique et on renvoi sur une fonction javascript  -->
