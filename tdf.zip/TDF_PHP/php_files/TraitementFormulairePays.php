<?php

	

	include '../php_files/php_class/bdd.class.php';
	include '../php_files/php_class/coureur.class.php';
	print_r($_POST);
	
	//di un clic a �t� d�clench� :
	if((isset($_POST['valider']))||(isset($_POST['maj']))||(isset($_POST['supprimer']))||(isset($_POST['reinitialiser']))){
		
		echo "traitement en cours","</br>";
		if(isset($_POST['valider'])){
			ajouterPaysBDD();
		}
		else if(isset($_POST['maj'])){
			majPaysBDD();
		}
		else if (isset($_POST['supprimer'])){
			supprimerPaysBDD();
		}
		else if (isset($_POST['supprimer'])){
			supprimerPaysBDD();
		}
		else if (isset($_POST['reinitialiser'])){
			//header('location:../module_ajax/exemple.php');
		}
	}
	else {echo "Aucun bouton selectionn�";}	
	
	
	
	function ajouterPaysBDD() {
		//print_r($_POST);
		$bdd = new BDD();
		
		
		$pays ="INSERT INTO TDF_PAYS (CODE_TDF,C_PAYS,NOM) values ('".$_POST['code_tdf']."', '".$_POST['code_pays']."', '".$_POST['nom']."')";
		$bdd->getBDD()->beginTransaction();
		//On ne peut pas faire :table avec les noms de tables ==> manuel. Uniquement les valeurs.
		$req = $bdd->getBDD()->prepare($pays);
		try {
			$req->execute();
			$bdd->getBDD()->commit();
			echo "ajout termin�,	";
		} catch (Exception $e) {
			printf("ERREUR : %s", $e->getMessage());
		}
		
		
	}
	
	
	function majPaysBDD(){
		//print_r($_POST);
		$bdd = new BDD();
		$bdd->getBDD()->beginTransaction();
		$numero = $_POST['id'];
		$pays = "UPDATE TDF_PAYS SET CODE_TDF='".$_POST['code_tdf']."', C_PAYS='".$_POST['code_pays']."', NOM='".$_POST['nom']."' WHERE CODE_TDF='".$_POST['code_tdf']."'";
		$req = $bdd->getBDD()->prepare($pays);
		try {
			$req->execute();
			$bdd->getBDD()->commit();
			echo "maj termin�,	";
		} catch (Exception $e) {
			printf("ERREUR : %s", $e->getMessage());
		}
		
		//header('location:../module_ajax/exemple.php');
	}
	
	function supprimerPaysBDD(){
		$bdd = new BDD();
		$bdd->getBDD()->beginTransaction();
		$numero = $_POST['id'];
		//On ne peut pas faire :table avec les noms de tables ==> manuel. Uniquement les valeurs.
		$pays = "DELETE FROM TDF_PAYS WHERE CODE_TDF='".$_POST['id']."'";
		$req = $bdd->getBDD()->prepare($pays);
		try {
			$req->execute();
			$bdd->getBDD()->commit();
			echo "suppression termin�,	";
		} catch (Exception $e) {
			printf("ERREUR : %s", $e->getMessage());
		}
		
		//header('location:../module_ajax/exemple.php');
	}
	
	
?>