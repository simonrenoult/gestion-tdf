<?php
	include './php_class/bdd.class.php';
	
	
function remplirtab() {	
	
	if(isset($_POST['executer'])){
		
		
	//$req ="select * from tdf_coureur where rownum <= 10";
		$bdd = new BDD();
		
		$req = strtoupper($_POST['area'])." where rownum <= ".$_POST['comboboxSQL'];
		echo $req;
		try {
			$query = $bdd->getBDD()->prepare($req);
			$query->execute();
			
			
		echo"<table width=\"100%\" border=\"1\" cellspacing=\"1\" cellpadding=\"1\" >";
		
		while ($donnee = $query->fetch(PDO::FETCH_NUM)){
				echo "<tr>";
				for($i=0;$i<count($donnee);$i++){
					echo "<td>".$donnee[$i]."</td>";
				}	
				echo"</tr>";
				
				
				
			}
			
			
			
			echo"</table>";	
			$query->closeCursor();
			
			
		}catch (Exception $e){}
		
	}	
}	
?>


 

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
		<title>Table coureur</title>
		<link rel="stylesheet" media="screen" type="text/css" title="Design" href="../css_files/SQL.css"  /> 	
	</head>
	<body>
	
	
	
		<div id="header">
			
			<h1>Base d'administration des tables du TDF 2011</h1>
			<h3><i>Execution de script SQL</i></h3>
				
		</div>
		
		<div id="scriptsql">
			<fieldset>
			<label>Votre requ�te SQL</label>
			
				<div id="zoneSQL">
					<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
					
					   <p><label for="comboboxSQL">Afficher  </label> 
	      				 <select name="comboboxSQL" id="comboboxSQL"> 
	      				 	<option value=10>10</option>
							<option value=20>20</option>
							<option value=30>30</option>
							<option value=40>40</option>
							<option value=50>50</option>
						</select>
						</p>
						
						
					<div id="SQLarea">
					<textarea rows="10" cols="100" name="area"><?php 	if(isset($_POST['executer'])){echo trim($_POST['area']);}?></textarea>
					</div>		
					
					
					<input type="submit" name="executer" value="Executer"  />
					
					</form>
					
					
					<div id = "tableauSQL">
						<?php remplirtab();?>
					</div>
					
					
				</div>
			</fieldset>
		
			
		</div>
	
	
	
	
	
	</body>
</html>

	