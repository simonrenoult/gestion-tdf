<?php

	

	include '../php_files/php_class/bdd.class.php';
	include '../php_files/php_class/coureur.class.php';
	print_r($_POST);
	
	//di un clic a �t� d�clench� :
	if((isset($_POST['valider']))||(isset($_POST['maj']))||(isset($_POST['supprimer']))||(isset($_POST['reinitialiser']))){
		
		echo "traitement en cours","</br>";
		if(isset($_POST['valider'])){
			ajouterCoureurBDD();
		}
		else if(isset($_POST['maj'])){
			majCoureurBDD();
		}
		else if (isset($_POST['supprimer'])){
			supprimerCoureurBDD();
		}
		else if (isset($_POST['supprimer'])){
			supprimerCoureurBDD();
		}
		else if (isset($_POST['reinitialiser'])){
			//header('location:../module_ajax/exemple.php');
		}
	}
	else {echo "Aucun bouton selectionn�";}	
	
	
	
	function ajouterCoureurBDD() {
		//print_r($_POST);
		$bdd = new BDD();
		$n_coureur = ($bdd->getBDD()->query('select max(n_coureur) as from tdf_coureur'));
		
		while ($donnee = $n_coureur->fetch())
		{
			$tab = $donnee;
		}
		$n_coureur->closeCursor();
		$numero = $tab[0];
		
		
		$coureur = new Coureur($numero+1, $_POST['nom'], $_POST['prenom'],$_POST['date_naissance'], $_POST['pays_origine'],$_POST['annee_tdf']);
		echo 'Insert into tdf_coureur (n_coureur, nom, prenom, annee_naissance, code_tdf,annee_tdf) values ('.$coureur->getn_coureur().','.strtoupper( $coureur->getnom()).','.ucfirst($coureur->getprenom()).','.$coureur->getannee_naissance().','.$coureur->getcode_tdf().','.$coureur->getannee_tdf().')';
		$bdd->getBDD()->beginTransaction();
		
		//On ne peut pas faire :table avec les noms de tables ==> manuel. Uniquement les valeurs.
		$req = $bdd->getBDD()->prepare('Insert into tdf_coureur (n_coureur, nom, prenom, annee_naissance, code_tdf, annee_tdf)  values (:champ1,:champ2,:champ3,:champ4,:champ5,:champ6)');
		try {
			$req->execute(array(
		
										':champ1'=>$coureur->getn_coureur(),
										':champ2'=>strtoupper( $coureur->getnom()),
										':champ3'=>ucfirst($coureur->getprenom()),
										':champ4'=>$coureur->getannee_naissance(),
										':champ5'=>$coureur->getcode_tdf(),
										':champ6'=>$coureur->getannee_tdf()
			)
			);
		
			$bdd->getBDD()->commit();
			echo "ajout termin�,	";
		} catch (Exception $e) {
			printf("ERREUR : %s", $e->getMessage());
		}
		
		//header('location:../module_ajax/exemple.php');
	}
	
	
	function majCoureurBDD(){
		//print_r($_POST);
		$bdd = new BDD();
		$bdd->getBDD()->beginTransaction();
		$numero = $_POST['id'];
		$coureur = new Coureur($numero,$_POST['nom'],$_POST['prenom'],$_POST['date_naissance'], $_POST['pays_origine'], $_POST['annee_tdf']);
		
		//On ne peut pas faire :table avec les noms de tables ==> manuel. Uniquement les valeurs.
		$req = $bdd->getBDD()->prepare('update tdf_coureur set n_coureur= :champ1,nom = :champ2,prenom = :champ3,annee_naissance = :champ4,code_tdf = :champ5,annee_tdf = :champ6 where n_coureur = :champ1 ');
		try {
			$req->execute(array(
		
												':champ1'=>$coureur->getn_coureur(),
												':champ2'=>strtoupper( $coureur->getnom()),
												':champ3'=>ucfirst($coureur->getprenom()),
												':champ4'=>$coureur->getannee_naissance(),
												':champ5'=>$coureur->getcode_tdf(),
												':champ6'=>$coureur->getannee_tdf()
			)
			);
		
			$bdd->getBDD()->commit();
			echo "maj termin�,	";
		} catch (Exception $e) {
			printf("ERREUR : %s", $e->getMessage());
		}
		
		//header('location:../module_ajax/exemple.php');
	}
	
	function supprimerCoureurBDD(){
		$bdd = new BDD();
		$bdd->getBDD()->beginTransaction();
		$numero = $_POST['id'];
		//On ne peut pas faire :table avec les noms de tables ==> manuel. Uniquement les valeurs.
		$req = $bdd->getBDD()->prepare('delete from tdf_coureur where n_coureur = :champ1 ');
		try {
			$req->execute(array(':champ1'=>$numero));
			$bdd->getBDD()->commit();
			echo "suppression termin�,	";
		} catch (Exception $e) {
			printf("ERREUR : %s", $e->getMessage());
		}
		
		//header('location:../module_ajax/exemple.php');
	}
	
	
?>