<?php
	
	
	class BDD {
		
		private $bdd;
		
		public function __construct(){
			$this->connexionBDD();
		}
		
		public function  connexionBDD() {
			try {
				$this->bdd = new PDO ("oci:dbname=//localhost:1521/xe", "admin", "admin");
				//printf("Connexion Ok");
			}
			catch(PDOException $e) {
				//printf("Echec de la connexion");
				//printf("ERREUR : %s", $e->getMessage());
			}
			
		}
		
		public function getBDD() {
			return $this->bdd;
		}
		
		
				
	}
	
	
	
	
	
	
	
	
	
	
	
?>