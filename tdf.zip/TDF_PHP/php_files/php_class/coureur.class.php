<?php

class Coureur {
	
	private $n_coureur;
	private $nom;
	private $prenom;
	private $annee_naissance;
	private $code_tdf;
	private $annee_tdf;
	
	 public function __CONSTRUCT ($n_coureur,$nom,$prenom,$annee_naissance,$code_tdf,$annee_tdf){
	 	$this->n_coureur = $n_coureur;
	 	$this->nom = $nom;
	 	$this->prenom = $prenom;
	 	$this->annee_naissance = $annee_naissance;
	 	$this->code_tdf = $code_tdf;
	 	$this->annee_tdf = $annee_tdf;
	 }
	 
	 public  function getn_coureur(){
	 	return $this->n_coureur;
	 }
	 
	 public  function getnom(){
	 	return $this->nom;
	 }
	 
	 public  function getprenom(){
	 	return $this->prenom;
	 }
	
	 public  function getannee_naissance(){
	 	return $this->annee_naissance;
	 }
	 public  function getcode_tdf(){
	 	return $this->code_tdf;
	 }
	 
	 public  function getannee_tdf(){
	 	return $this->annee_tdf;
	 }
}



?>